
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'karnoldf',
  applicationName: 'serverless-capstone-app',
  appUid: 'fc5FMphLB7rC2LmxVn',
  orgUid: 'ce8db805-f85f-4ceb-bdd4-fda2d3c7b992',
  deploymentUid: 'ef3949fe-6ca7-4ae0-8789-f8d3cf2d7904',
  serviceName: 'serverless-capstone-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-capstone-app-dev-auth', timeout: 6 };

try {
  const userHandler = require('./src/functions/auth/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}